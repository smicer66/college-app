﻿<%@ Control Language="VB" AutoEventWireup="false" CodeFile="checkout_attachments.ascx.vb" Inherits="webcontrols_checkout_attachments" %>
<%@ Register Assembly="PSWebEnrolmentKit" Namespace="CompassCC.ProSolution.PSWebEnrolmentKit"
    TagPrefix="cc1" %>

<br />
<br />

<ol class="breadcrumb" id="breadcrumbenrols" runat="server">
    <li><a href="default.aspx">Home</a></li>
    <li><a href="webenrolment.aspx?page=~/webcontrols/checkout.ascx">Checkout</a></li>
    <li><a href="webenrolment.aspx?page=~/webcontrols/checkout_enrolments.ascx">Personal Details</a></li>

    <li><a href="webenrolment.aspx?page=~/webcontrols/checkout_enrolments2.ascx">Further Details</a></li>
    <!--<li><a href="webenrolment.aspx?page=~/webcontrols/checkout_parent_guardian.ascx">Parent / Guardian</a></li>-->
    <li><a href="webenrolment.aspx?page=~/webcontrols/checkout_school_employer.ascx">School / Employer</a></li>
    <li><a href="webenrolment.aspx?page=~/webcontrols/checkout_prior_attainment.ascx">Prior Attainment</a></li>
    <!--<li><a href="webenrolment.aspx?page=~/webcontrols/checkout_quals_on_entry.ascx">Quals on Entry</a></li>-->
    <!--<li><a href="webenrolment.aspx?page=~/webcontrols/checkout_references.ascx">References</a></li>-->
    <!--<li><a href="webenrolment.aspx?page=~/webcontrols/checkout_employment.ascx">Employment</a></li>-->
    <li class="active">Attachments</li>


</ol>

<div class="panel panel-info" id="divMain" runat="server">
    <div class="panel-heading">Attachments</div>

    <p>
      <strong>* Please use this page to upload evidence to support your enrolment. You can upload a picture using your mobile phone as long as the document is legible, all files upload in this section must be in the .jpg, .png or .jpeg file formats.</strong>    
      </p>
    <ul runat="server" id="ulList">
    <li>You must upload 1 proof of identity such as a national insurance (NI) card, national ID card, correspondence from your school, passport, birth certificate or driving licence</li>
    <li>If you have not lived in the UK / Ireland for the last three years you must upload any residency documents that you have which may include your passport, residence permit / card or evidence of your ‘Settled’ or ‘Pre-Settled’ residence status.  </li>

</ul>
    <div>        
        <table class="table table-striped text-center">
            <tbody>
                <tr>
                    <td class="text=center" style="width: 20%">Type of Evidence</td>
                    <td style="width: 50%">Notes</td>
                    <td style="width: 20%">Upload File</td>
                    <td style="width: 10%"></td>
                </tr>
                <tr>
                    <td>
                        <div>
                            <asp:DropDownList ID="ddlTypeOfEvidence" runat="server">
                                <asp:ListItem Text="Select" Value=""></asp:ListItem>
                                <%--<asp:ListItem Text="Passport" Value="Passport"></asp:ListItem>--%>
                                <%--<asp:ListItem Text="Utility Bill/Proof of Address" Value="Utility Bill/Proof of Address"></asp:ListItem>--%>
                                <%--<asp:ListItem Text="Proof of Benefits" Value="Proof of Benefits"></asp:ListItem>--%>
                               <asp:ListItem Text="Proof of Identity" Value="Proof of Identity"></asp:ListItem>
                              <asp:ListItem Text="Residence status" Value="Residence status"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                    </td>
                    <td>
                        <div>
                            <asp:TextBox ID="txtNotes" runat="server" TextMode="MultiLine" Rows="8" Width="100%"></asp:TextBox>
                        </div>
                    </td>
                    <td>
                        <div>
                            <%--
                                Following properties are there to use in the File Upload control
                                - IsRequired (To set control mandatory)
                                - RequiredErrorMessage (A message to display when user is not uploading file)
                                - MaxAllowedFileSize (Maximum size allowed for a file upload in KB). Use this to override value set in System Setting of same name.
                                - MaxAllowedFileSizeErrorMessage  (A message to display when user has uploaded larger file than allowed)
                                - SupportedFileTypes (File Types supported by the control (.jpg, .png, .xlsx)). Use this to override value set in System Setting of same name.
                                - SupportedFileTypesErrorMessage (A message to display when user has uploaded file of type which is not valid)
                                - HideUserInfoOnTooltip (To prevent showing of information related to file upload requirements)
                                - UserInfo (User Information related to file upload requirements - if need to display at any specific location manually)
                                --%>
                            <cc1:CCCFileUpload ID="fuAttachment" runat="server" data-html="true"  ClientIDMode="static"  IsRequired="true" MaxAllowedFileSize="49152" />
                        </div>
                    </td>
                    <td>
                        <div>
                            <asp:Button ID="btnUpload" runat="server" Text="Upload" CssClass="btn btn-success" CausesValidation="true" />
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <br />
    <asp:ValidationSummary ID="vsAttachments" runat="server" CssClass="alert alert-danger" />
    <hr />
    <div>
        <table id="tblUploadedInfo" class="table table-striped table-bordered text-center" style="border-style: None;">
            <tbody>
                <asp:Repeater ID="rptAttachments" runat="server" OnItemCommand="rptAttachments_ItemCommand">
                    <HeaderTemplate>
                        <tr class="searchgridheader">
                            <th scope="col" style="width: 20%">Type of Evidence</th>
                            <th scope="col">Notes</th>
                            <th scope="col" style="width: 15%">Attachment</th>
                            <th scope="col" style="width: 10%">Remove</th>
                        </tr>
                    </HeaderTemplate>
                    <ItemTemplate>
                        <tr class="searchgridcell text-left">
                            <td><%# Eval("TypeOfEvidence") %></td>
                            <td><%# Eval("Notes") %></td>
                            <td><%# Eval("FileName") %></td>
                            <td class="text-center">
                                <asp:Button ID="btnRemove" runat="server" Text="X" CssClass="btn btn-danger" CommandName="RemoveAttachment" CommandArgument='<%# Eval("AttachmentID") %>' OnClientClick="return confirmDeletion()" /></td>
                        </tr>
                    </ItemTemplate>
                </asp:Repeater>
                <tr id="trNoItems" runat="server" class="searchgridcell" visible="false">
                    <td colspan="4">No attachments uploaded yet
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<cc1:CCCButton ID="btnBack" runat="server" Text="Back" ImageResource="btnBack" LinkResource="checkout_prior_attainment" />
<cc1:CCCButton ID="btnContinue" runat="server" Text="Continue" ImageResource="btnContinue" />

<!--
<script type="text/javascript">
    $("#btnChooseFile").click(function () {
        $('#fuAttachment').click();
    });
    function confirmDeletion() {
        var result = confirm("Are you sure you want to delete this attachment? Press OK to continue deletion.");
        if (result) {
            return true;
        }
        return false;
    }    
</script>
-->
<script type="text/javascript" src="<%=ResolveUrl("~/webcontrols/checkout_attachments.js") %>"></script>