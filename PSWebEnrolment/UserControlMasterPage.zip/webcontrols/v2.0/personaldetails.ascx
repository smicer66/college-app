﻿<%@ control Language="VB" AutoEventWireup="false" CodeFile="personaldetails.ascx.vb" Inherits="personaldetails"  %>
<%@ Register Assembly="PSWebEnrolmentKit" Namespace="CompassCC.ProSolution.PSWebEnrolmentKit"
    TagPrefix="cc1" %>

<%-- <script src="/js/jquery-1.10.2.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/south-street/jquery-ui.css" />

  <script>
      $(function () {
          $(function () {
              $("#txtDateOfBirth").datepicker({ dateFormat: "dd/mm/yy", changeMonth: true, changeYear: true, yearRange: "1930:2000" })
          });
      });
  </script>--%>

    <style>
    :root {
      --primary: #2563eb;
      --primary-light: #eff6ff;
      --success: #16a34a;
      --text: #172b4d;
      --muted: #64748b;
      --border: #e2e8f0;
      --background: #f5f7fb;
      --white: #ffffff;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Ryker, Arial, sans-serif;
      background: var(--background);
      color: var(--text);
      overflow-x: hidden;
    }

    button {
      font: inherit;
    }

    .container {
      width: 100%;
      max-width: 1400px;
      margin: 0 auto;
      padding: 32px 24px;
    }

    /* Breadcrumbs */

    .breadcrumbs {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      font-size: 14px;
      margin-bottom: 32px;
      color: var(--muted);
    }

    .breadcrumbs a {
      color: #536987;
      text-decoration: none;
    }

    .breadcrumbs .separator {
      color: #94a3b8;
    }

    .breadcrumbs .active {
      font-weight: 700;
      color: var(--text);
    }

    /* Progress tracker */

    .stepper {
      display: grid;
      grid-template-columns: repeat(12, minmax(0, 1fr));
      gap: 0;
      margin-bottom: 38px;
    }

    .step {
      position: relative;
      text-align: center;
      min-width: 0;
      cursor: pointer;
    }

    .step::before {
      content: "";
      position: absolute;
      top: 16px;
      left: 0;
      width: 100%;
      height: 2px;
      background: #d7e0ec;
      z-index: 0;
    }

    .step:first-child::before {
      left: 50%;
      width: 50%;
    }

    .step:last-child::before {
      width: 50%;
    }

    .step-number {
      position: relative;
      z-index: 1;
      width: 34px;
      height: 34px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 10px;
      border-radius: 50%;
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      color: #475569;
      font-weight: 700;
      font-size: 13px;
    }

    .step-label {
      display: block;
      padding: 0 3px;
      font-size: 12px;
      line-height: 1.45;
      color: #536987;
      overflow-wrap: anywhere;
    }

    .step.active .step-number {
      background: var(--primary);
      border-color: var(--primary);
      color: white;
    }

    .step.active .step-label {
      color: var(--primary);
      font-weight: 700;
    }

    .step.completed .step-number {
      background: var(--success);
      border-color: var(--success);
      color: white;
    }

    .step.completed::before {
      background: var(--success);
    }

    .step:focus-visible {
      outline: 3px solid #93c5fd;
      outline-offset: 4px;
    }

    /* Main card */

    .card {
      background: var(--white);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 40px;
      box-shadow: 0 4px 20px rgba(15, 23, 42, 0.04);
    }

    .card h1 {
      margin: 0 0 12px;
      font-size: clamp(24px, 3vw, 32px);
      line-height: 1.25;
    }

    .intro {
      font-size: 16px;
      color: #536987;
      line-height: 1.7;
      margin: 0 0 24px;
      max-width: 850px;
    }

    /* Information box */

    .info-box {
      display: flex;
      align-items: flex-start;
      gap: 14px;
      padding: 20px;
      border: 1px solid #bfdbfe;
      border-radius: 8px;
      background: #eff6ff;
      margin-top: 28px;
    }

    .info-icon {
      flex: 0 0 auto;
      width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: var(--primary);
      color: white;
      font-weight: 700;
    }

    .info-box h3 {
      margin: 0 0 8px;
      font-size: 16px;
    }

    .info-box p {
      margin: 0;
      font-size: 14px;
      line-height: 1.6;
      color: #365b91;
    }

    /* Content */

    .step-content {
      min-height: 260px;
    }

    .step-content h2 {
      font-size: 23px;
      margin: 0 0 16px;
    }

    .step-content p {
      color: #536987;
      line-height: 1.7;
      max-width: 850px;
    }

    .step-content ul {
      color: #536987;
      line-height: 1.8;
      padding-left: 20px;
    }

    /* Footer navigation */

    .card-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      border-top: 1px solid var(--border);
      margin-top: 32px;
      padding-top: 24px;
    }

    .btn {
      border: none;
      border-radius: 7px;
      padding: 13px 24px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.2s;
    }

    .btn-primary {
      background: var(--primary);
      color: white;
    }

    .btn-primary:hover {
      background: #1d4ed8;
    }

    .btn-secondary {
      background: #eef2f7;
      color: #64748b;
    }

    .btn-secondary:hover:not(:disabled) {
      background: #e2e8f0;
    }

    .btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .progress-text {
      font-size: 13px;
      color: var(--muted);
      text-align: center;
    }

    /* Tablet */

    @media (max-width: 1100px) {
      .stepper {
        grid-template-columns: repeat(6, minmax(0, 1fr));
        row-gap: 24px;
      }

      .step::before {
        display: none;
      }

      .step-label {
        font-size: 12px;
      }
    }

    /* Mobile */

    @media (max-width: 600px) {
      .container {
        padding: 20px 12px;
      }

      .breadcrumbs {
        margin-bottom: 20px;
        font-size: 12px;
        gap: 6px;
      }

      .stepper {
        display: flex;
        flex-direction: column;
        gap: 0;
        margin-bottom: 24px;
      }

      .step {
        display: flex;
        align-items: center;
        gap: 14px;
        text-align: left;
        padding: 9px 12px;
        border-radius: 8px;
        min-height: 48px;
      }

      .step::before {
        display: none;
      }

      .step-number {
        flex: 0 0 32px;
        width: 32px;
        height: 32px;
        margin: 0;
      }

      .step-label {
        padding: 0;
        font-size: 13px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }

      .step.active {
        background: var(--primary-light);
      }

      .card {
        padding: 24px 18px;
        border-radius: 10px;
      }

      .card h1 {
        font-size: 25px;
      }

      .intro {
        font-size: 14px;
      }

      .info-box {
        padding: 16px;
        gap: 10px;
      }

      .step-content {
        min-height: 220px;
      }

      .step-content h2 {
        font-size: 21px;
      }

      .card-footer {
        flex-wrap: wrap;
      }

      .progress-text {
        order: 3;
        flex-basis: 100%;
      }

      .btn {
        padding: 12px 18px;
      }
    }

    /* Personal Details form */
    .form-section { margin-top: 28px; padding-top: 24px; border-top: 1px solid var(--border); }
    .form-section:first-of-type { margin-top: 8px; }
    .form-section h2 { margin: 0 0 20px; font-size: 21px; color: var(--text); }
    .form-grid { display: grid; gap: 20px 24px; }
    .form-group { min-width: 0; }
    .form-group.full-width { grid-column: 1 / -1; }
    .form-group label, .field-label { display:block; margin-bottom:7px; font-size:14px; font-weight:700; color:var(--text); }
    .form-control { width:100%; min-width:0; height:44px; padding:10px 12px; border:1px solid #cbd5e1; border-radius:7px; background:#fff; color:var(--text); font:inherit; }
    .form-control:focus { outline:3px solid #bfdbfe; outline-offset:1px; border-color:var(--primary); }
    .checkbox-row { display:flex; align-items:flex-start; gap:9px; margin-top:9px; font-size:13px; color:#475569; }
    .checkbox-row input { width:17px; height:17px; margin-top:1px; flex:0 0 auto; accent-color:var(--primary); }
    .conditional-field[hidden] { display:none !important; }
    .field-hint { margin:6px 0 0; font-size:12px; color:var(--muted); }
    @media (max-width: 600px) { .form-grid { grid-template-columns:1fr !important; gap:17px; } .form-group.full-width { grid-column:auto; } .form-control { font-size:16px; } }
    .form-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }


    .bgError{
        color: #721c24; !important;
        background-color: #f8d7da !important;
        border: 1px solid #f5c6cb;
        position: relative;
        padding: .75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem;
        font-weight: bold !important;
    }

    .bgError ul li{
        font-weight: 100 !important;
    }

    .error{
        display: none !important;
    }

    .pad20{
        padding-top: 20px !important;
    }

    span {
        font-weight: 100 !important
    }
  </style>


    
<script>

    const toggle = (controlId, groupId) => {
        const control = document.getElementById(controlId), group = document.getElementById(groupId);
        if (!control || !group) return;
        const apply = () => { group.hidden = control.type === "checkbox" ? !control.checked : control.value !== "other"; };
        control.addEventListener("change", apply); apply();
    };

    function t() {
        toggle("different-first-name", "known-first-group");
        toggle("different-last-name", "known-last-group");
    }

    t();


    document.addEventListener("DOMContentLoaded", function () {

        var select = document.querySelector('.sex select');
        select.options[1].text = "Female";
        select.options[2].text = "Male";

        var selectPronoun = document.querySelector('.PreferredPronouns select');
        for (var i = 0; i < selectPronoun.options.length; i++) {
            var t = selectPronoun.options[i].text.split(' - ');
            //console.log(t)
            selectPronoun.options[i].text = t.length == 1 ? t[0] : t[1];

        }


        var primaryLanguage = document.querySelector('.StudentFirstLanguageID select');
        for (var i = 0; i < selectPronoun.options.length; i++) {
            var t = selectPronoun.options[i].text.split(' - ');
            //console.log(t)
            selectPronoun.options[i].text = t.length == 1 ? t[0] : t[1];

        }

        var requiredSpans = ["lblTitle", "lblFirstForename", "lblSurname", "lblDateOfBirth", "lblSex", "lblPreferredPronounID", "lblEthnicGroupID", "lblEmail", "lblEmailRetype",
            "lblStudentFirstLanguageID", "lblMobileTel", "lblDateofBirth", "lblCountryID"];
        requiredSpans.forEach(id => {
            const element = document.getElementById(id);

            if (element) {
                element.insertAdjacentHTML(
                    "beforeend",
                    ' <span style="color:red;">*</span>'
                );
            }
        });
    })

</script>


<div class="step-content" id="step-content">
    <div>
        <asp:ValidationSummary ID="ValidationSummary1" runat="server" HeaderText="We found some errors in the information you provided. Please fix these errors:" CssClass="bgError" ForeColor="" />
    </div>
    <h1>Personal Details</h1>
    <p class="intro">Please provide your personal details.</p>
    <section class="form-section" aria-labelledby="personal-heading">
        <h2 id="personal-heading">Your Personal details</h2>
        <div class="form-grid">  
            <div class=" form-group" id="Div1">
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="Title" ID="Title" runat="server" IsRequired="false" LabelWidth="200" CustomCaption="Title" />
            </div>
        </div>
        <div class="form-grid pad20">  
            <div class="clear form-group">
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="FirstForename" ID="StudentEnrolmentField1" runat="server" IsRequired="true" LabelWidth="200" CustomCaption="Legal first name" />
                <label class="checkbox-row">
                    <asp:checkbox id="KnownAsFirstName" runat="server" Text="" AutoPostBack="True" />
                    <span>I am known by a different first name</span>
                </label>
            </div>  
            <div class=" form-group">
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="Surname" ID="fldSurname" runat="server" IsRequired="true" LabelWidth="200"    CustomCaption="Legal last name"/>
                <label class="checkbox-row">
                    <asp:checkbox id="KnownAsLastName" runat="server" Text=""  AutoPostBack="True" /> 
                    <span>I am known by a different last name</span>
                </label>
            </div>  
            <div class=" form-group" id="knownFirstGroup" runat="server" visible="false">
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="knownas" ID="knownas" runat="server" IsRequired="false" LabelWidth="200" CustomCaption="Known as first name" />
            </div>  
            <div class=" form-group" id="knownLastGroup" runat="server" visible="false">
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="StudentDetailUserDefined5" ID="StudentEnrolmentField12" runat="server" IsRequired="false" LabelWidth="200"    CustomCaption="Known as last name"/>
            </div>
            <div class="form-group">
                <!--<label for="middle-names">Legal Middle name(s)</label>
                <input class="form-control" id="middle-names" name="middleNames" type="text" autocomplete="additional-name">-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="OtherForenames" ID="OtherForenames" runat="server" IsRequired="false" LabelWidth="200" CustomCaption="Legal Middle name(s)"/>
            </div>
            <div class="form-group">
                <span for="legal-first-name" id="lblDateofBirth">Date of birth</span>
                <!--<label for="date-of-birth">Date of birth</label>
                <input class="form-control" id="dateOfBirth" name="dateOfBirth" runat="server" type="date">
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="DateOfBirth" CssClass="dateOfBirth" ID="StudentEnrolmentField4" runat="server" IsRequired="true" LabelWidth="200" CustomCaption="Date of birth"/>-->
                <input class="form-control dateOfBirth" id="datepicker" runat="server" name="DateOfBirth" type="text" Placeholder="DD MMM YYYY" />
                <p class="field-hint" runat="server" id="ageParagraph"></p>
            </div>
            <div class="form-group sex">
                <!--<label for="biological-sex">Biological sex</label>
                <select class="form-control" id="biological-sex" name="biologicalSex"><option value="">Please select</option><option>Female</option><option>Male</option><option>Intersex</option><option>Prefer not to say</option>
                </select>-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="Sex" ID="fldSex" runat="server"  IsRequired="true" CustomCaption="Biological sex"/>
            </div>
            <div class="form-group PreferredPronouns">
                <!--<label for="pronouns">Preferred pronouns</label>
                <select class="form-control" id="pronouns" name="pronouns"><option value="">Please select</option><option>She / her</option><option>He / him</option><option>They / them</option><option>Other</option><option>Prefer not to say</option>
                </select>-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="PreferredPronounID" ID="PreferredPronouns" runat="server"  IsRequired="true" CustomCaption="Preferred pronouns"/>
            </div>
            <div class="form-group">
                <!--<label for="ethnicity">Ethnicity</label>
                <input class="form-control" id="ethnicity" name="ethnicity" type="text">-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="EthnicGroupID" ID="EthnicGroupID" runat="server"  IsRequired="true" CustomCaption="Ethnicity"/>
            </div>
            <div class="form-group">
                <!--<label for="primary-language">Primary language</label>
                <select class="form-control" id="primary-language" name="primaryLanguage"><option value="">Please select</option><option>English</option><option>Welsh</option><option>Polish</option><option>Arabic</option><option>Somali</option><option value="other">Other</option></select>-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="StudentFirstLanguageID" ID="StudentFirstLanguageID" runat="server"  IsRequired="true" CustomCaption="Primary language"/>
            </div>
            <div class="form-group conditional-field full-width" id="other-language-group" hidden>
                <!--<label for="other-language">Please specify primary language</label>
                <input class="form-control" id="other-language" name="otherLanguage" type="text">-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="StudentDetailUserDefined1" ID="StudentDetailUserDefined1" runat="server"  IsRequired="false" CustomCaption="Please specify primary language"/>
            </div>
        </div>
    </section>
    <section class="form-section" aria-labelledby="education-heading">
        <h2 id="education-heading">Your Education</h2>
        <div class="form-grid">
            <div class="form-group">
                <!--<label for="previous-school">Previous school</label>
                <select class="form-control" id="previous-school" name="previousSchool"><option value="">Please select</option><option>Ashton Park School</option><option>Bedminster Down School</option><option>Bridge Learning Campus</option><option>City of Bristol College</option><option value="other">Other</option></select>-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="SchoolID" ID="SchoolID" runat="server"  IsRequired="true" CustomCaption="Previous school"/>
            </div>
            <div class="form-group conditional-field" id="other-school-group" hidden>
                <!--<label for="other-school">Enter school name and town</label>
                <input class="form-control" id="other-school" name="otherSchool" type="text">-->
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="StudentDetailUserDefined4" ID="StudentEnrolmentField10" runat="server"  IsRequired="false" CustomCaption="Enter school name and town"/>
            </div>
        </div>
    </section>
</div>

<!--<script src="/js/jquery-1.10.2.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.10.3/themes/south-street/jquery-ui.css" />

<script>
    $(function () {
        $(function () {
            var currentYear = new Date().getFullYear();
            var dateRange = (currentYear-70).toString() + ":" + (currentYear - 14).toString();
            $(".dateOfBirth").datepicker({ dateFormat: "dd M yy", changeMonth: true, changeYear: true, yearRange: dateRange })
        });
    });
</script>-->

<%--<div class="panel panel-success">
    <div class="panel-heading">Photo</div>
    <p>If you would like to upload a photo, you can do that here. </p>
    <div class=" form-group">
    <asp:FileUpload ID="FileUpload1" runat="server" />
        </div>
    </div>--%>

<div class="card-footer">
    <cc1:CCCButton CssClass="btn btn-primary" ID="btnBack" runat="server" Text="← Back" LinkResource="checkout_aspx" />
    <cc1:CCCButton CssClass="btn btn-primary" ID="btnContinue" runat="server" Text="Next →" LinkResource="contactdetails_aspx" CausesValidation="True" /> <!---->
</div>

