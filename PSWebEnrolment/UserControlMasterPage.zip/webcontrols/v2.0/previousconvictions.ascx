﻿<%@ control Language="VB" AutoEventWireup="false" CodeFile="previousconvictions.ascx.vb" Inherits="previousconvictions"  %>
<%@ Register Assembly="PSWebEnrolmentKit" Namespace="CompassCC.ProSolution.PSWebEnrolmentKit"
    TagPrefix="cc1" %>

<%-- <script src="/js/jquery-1.10.2.js"></script>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/south-street/jquery-ui.css" />

  <script>
      $(function () {
          $(function () {
              $("#txtDateOfBirth").datepicker({ dateFormat: "dd/mm/yy", changeMonth: true, changeYear: true, yearRange: "1930:2000" })
          });
      });
  </script>--%>

    <style>
    :root {
      --primary: #2563eb;
      --primary-light: #eff6ff;
      --success: #16a34a;
      --text: #172b4d;
      --muted: #64748b;
      --border: #e2e8f0;
      --background: #f5f7fb;
      --white: #ffffff;
    }

    * {
      box-sizing: border-box;
    }

    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: var(--background);
      color: var(--text);
      overflow-x: hidden;
    }

    button {
      font: inherit;
    }

    .container {
      width: 100%;
      max-width: 1400px;
      margin: 0 auto;
      padding: 32px 24px;
    }

    /* Breadcrumbs */

    .breadcrumbs {
      display: flex;
      flex-wrap: wrap;
      gap: 10px;
      align-items: center;
      font-size: 14px;
      margin-bottom: 32px;
      color: var(--muted);
    }

    .breadcrumbs a {
      color: #536987;
      text-decoration: none;
    }

    .breadcrumbs .separator {
      color: #94a3b8;
    }

    .breadcrumbs .active {
      font-weight: 700;
      color: var(--text);
    }

    /* Progress tracker */

    .stepper {
      display: grid;
      grid-template-columns: repeat(12, minmax(0, 1fr));
      gap: 0;
      margin-bottom: 38px;
    }

    .step {
      position: relative;
      text-align: center;
      min-width: 0;
      cursor: pointer;
    }

    .step::before {
      content: "";
      position: absolute;
      top: 16px;
      left: 0;
      width: 100%;
      height: 2px;
      background: #d7e0ec;
      z-index: 0;
    }

    .step:first-child::before {
      left: 50%;
      width: 50%;
    }

    .step:last-child::before {
      width: 50%;
    }

    .step-number {
      position: relative;
      z-index: 1;
      width: 34px;
      height: 34px;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 10px;
      border-radius: 50%;
      background: #f8fafc;
      border: 1px solid #cbd5e1;
      color: #475569;
      font-weight: 700;
      font-size: 13px;
    }

    .step-label {
      display: block;
      padding: 0 3px;
      font-size: 12px;
      line-height: 1.45;
      color: #536987;
      overflow-wrap: anywhere;
    }

    .step.active .step-number {
      background: var(--primary);
      border-color: var(--primary);
      color: white;
    }

    .step.active .step-label {
      color: var(--primary);
      font-weight: 700;
    }

    .step.completed .step-number {
      background: var(--success);
      border-color: var(--success);
      color: white;
    }

    .step.completed::before {
      background: var(--success);
    }

    .step:focus-visible {
      outline: 3px solid #93c5fd;
      outline-offset: 4px;
    }

    /* Main card */

    .card {
      background: var(--white);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 40px;
      box-shadow: 0 4px 20px rgba(15, 23, 42, 0.04);
    }

    .card h1 {
      margin: 0 0 12px;
      font-size: clamp(24px, 3vw, 32px);
      line-height: 1.25;
    }

    .intro {
      font-size: 16px;
      color: #536987;
      line-height: 1.7;
      margin: 0 0 24px;
      max-width: 850px;
    }

    /* Information box */

    .info-box {
      display: flex;
      align-items: flex-start;
      gap: 14px;
      padding: 20px;
      border: 1px solid #bfdbfe;
      border-radius: 8px;
      background: #eff6ff;
      margin-top: 28px;
    }

    .info-icon {
      flex: 0 0 auto;
      width: 28px;
      height: 28px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      background: var(--primary);
      color: white;
      font-weight: 700;
    }

    .info-box h3 {
      margin: 0 0 8px;
      font-size: 16px;
    }

    .info-box p {
      margin: 0;
      font-size: 14px;
      line-height: 1.6;
      color: #365b91;
    }

    /* Content */

    .step-content {
      min-height: 260px;
    }

    .step-content h2 {
      font-size: 23px;
      margin: 0 0 16px;
    }

    .step-content p {
      color: #536987;
      line-height: 1.7;
      max-width: 850px;
    }

    .step-content ul {
      color: #536987;
      line-height: 1.8;
      padding-left: 20px;
    }

    /* Footer navigation */

    .card-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 16px;
      border-top: 1px solid var(--border);
      margin-top: 32px;
      padding-top: 24px;
    }

    .btn {
      border: none;
      border-radius: 7px;
      padding: 13px 24px;
      font-size: 14px;
      font-weight: 700;
      cursor: pointer;
      transition: background 0.2s;
    }

    .btn-primary {
      background: var(--primary);
      color: white;
    }

    .btn-primary:hover {
      background: #1d4ed8;
    }

    .btn-secondary {
      background: #eef2f7;
      color: #64748b;
    }

    .btn-secondary:hover:not(:disabled) {
      background: #e2e8f0;
    }

    .btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .progress-text {
      font-size: 13px;
      color: var(--muted);
      text-align: center;
    }

    /* Tablet */

    @media (max-width: 1100px) {
      .stepper {
        grid-template-columns: repeat(6, minmax(0, 1fr));
        row-gap: 24px;
      }

      .step::before {
        display: none;
      }

      .step-label {
        font-size: 12px;
      }
    }

    /* Mobile */

    @media (max-width: 600px) {
      .container {
        padding: 20px 12px;
      }

      .breadcrumbs {
        margin-bottom: 20px;
        font-size: 12px;
        gap: 6px;
      }

      .stepper {
        display: flex;
        flex-direction: column;
        gap: 0;
        margin-bottom: 24px;
      }

      .step {
        display: flex;
        align-items: center;
        gap: 14px;
        text-align: left;
        padding: 9px 12px;
        border-radius: 8px;
        min-height: 48px;
      }

      .step::before {
        display: none;
      }

      .step-number {
        flex: 0 0 32px;
        width: 32px;
        height: 32px;
        margin: 0;
      }

      .step-label {
        padding: 0;
        font-size: 13px;
        line-height: 1.4;
        overflow-wrap: anywhere;
      }

      .step.active {
        background: var(--primary-light);
      }

      .card {
        padding: 24px 18px;
        border-radius: 10px;
      }

      .card h1 {
        font-size: 25px;
      }

      .intro {
        font-size: 14px;
      }

      .info-box {
        padding: 16px;
        gap: 10px;
      }

      .step-content {
        min-height: 220px;
      }

      .step-content h2 {
        font-size: 21px;
      }

      .card-footer {
        flex-wrap: wrap;
      }

      .progress-text {
        order: 3;
        flex-basis: 100%;
      }

      .btn {
        padding: 12px 18px;
      }
    }

    /* Personal Details form */
    .form-section { margin-top: 28px; padding-top: 24px; border-top: 1px solid var(--border); }
    .form-section:first-of-type { margin-top: 8px; }
    .form-section h2 { margin: 0 0 20px; font-size: 21px; color: var(--text); }
    .form-grid { display: grid; gap: 20px 24px; }
    .form-group { min-width: 0; }
    .form-group.full-width { grid-column: 1 / -1; }
    .form-group label, .field-label { display:block; margin-bottom:7px; font-size:14px; font-weight:700; color:var(--text); }
    .form-control { width:100%; min-width:0; height:44px; padding:10px 12px; border:1px solid #cbd5e1; border-radius:7px; background:#fff; color:var(--text); font:inherit; }
    .form-control:focus { outline:3px solid #bfdbfe; outline-offset:1px; border-color:var(--primary); }
    .checkbox-row { display:flex; align-items:flex-start; gap:9px; margin-top:9px; font-size:13px; color:#475569; }
    .checkbox-row input { width:17px; height:17px; margin-top:1px; flex:0 0 auto; accent-color:var(--primary); }
    .conditional-field[hidden] { display:none !important; }
    .field-hint { margin:6px 0 0; font-size:12px; color:var(--muted); }
    @media (max-width: 600px) { .form-grid { grid-template-columns:1fr !important; gap:17px; } .form-group.full-width { grid-column:auto; } .form-control { font-size:16px; } }
    .form-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  
    /* Contact Details */
    .form-section{margin-top:28px}
    .form-section+.form-section{margin-top:34px;padding-top:28px;border-top:1px solid var(--border)}
    .form-section h2{margin:0 0 8px;font-size:21px}
    .section-help{margin:0 0 20px;color:var(--muted);font-size:14px;line-height:1.6}
    .contact-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:20px 24px}
    .form-group{min-width:0}
    .full-width{grid-column:1/-1}
    .form-group label,.field-label{display:block;margin-bottom:7px;font-size:14px;font-weight:700;color:var(--text)}
    .required{color:#b91c1c}
    .form-control{width:100%;min-height:44px;padding:10px 12px;border:1px solid #cbd5e1;border-radius:7px;background:#fff;color:var(--text);font:inherit}
    .form-control:focus{outline:3px solid #bfdbfe;border-color:var(--primary)}
    .checkbox-row{display:flex!important;align-items:flex-start;gap:9px;margin-top:10px;font-weight:400!important;color:#475569!important}
    .checkbox-row input{width:18px;height:18px;margin:1px 0 0;accent-color:var(--primary);flex:0 0 auto}
    .postcode-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:end}
    .lookup-btn{min-height:44px;white-space:nowrap;padding:10px 16px}
    .address-results{margin-top:10px}
    .field-error{display:none;margin-top:6px;color:#b91c1c;font-size:13px}
    .field-error.visible{display:block}
    .hidden{display:none!important}
    @media(max-width:700px){.contact-grid{grid-template-columns:1fr;gap:18px}.full-width{grid-column:auto}}
    @media(max-width:430px){.postcode-row{gap:7px}.lookup-btn{padding:10px 11px;font-size:12px}}


    /* Parent / Carer Details */
    .radio-group{display:flex;flex-wrap:wrap;gap:12px 22px;min-height:44px;align-items:center}
    .radio-option{display:flex!important;align-items:center;gap:8px;margin:0!important;font-weight:400!important;color:#475569!important;cursor:pointer}
    .radio-option input{width:18px;height:18px;margin:0;accent-color:var(--primary)}
    .form-hint{margin:6px 0 0;color:var(--muted);font-size:13px;line-height:1.45}


    /* Residency Status */
    .advice-box{padding:18px 20px;border:1px solid #bfdbfe;border-radius:8px;background:var(--primary-light);color:#365b91;font-size:14px;line-height:1.65;margin-bottom:22px}
    .advice-box strong{color:var(--text)}
    .date-format{margin-top:6px;color:var(--muted);font-size:12px}


    /* Qualifications */
    .section-heading-row{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:18px}
    .section-heading-row h2{margin:0 0 8px}
    .section-heading-row .section-help{margin-bottom:0}
    .qualification-editor{padding:20px;border:1px solid var(--border);border-radius:9px;background:#f8fafc}
    .qualification-editor .contact-grid{align-items:end}
    .qualification-actions{display:flex;justify-content:flex-end;align-items:end;height:100%}
    .qualification-table-wrap{width:100%;overflow-x:auto;border:1px solid var(--border);border-radius:9px}
    .qualification-table{width:100%;border-collapse:collapse;min-width:720px;background:#fff}
    .qualification-table th,.qualification-table td{padding:14px 16px;border-bottom:1px solid var(--border);text-align:left;font-size:14px;vertical-align:middle}
    .qualification-table th{background:#f8fafc;color:var(--text);font-weight:700}
    .qualification-table tbody tr:last-child td{border-bottom:0}
    .empty-row td{text-align:center;color:var(--muted);padding:26px 16px}
    .btn-danger{background:#fff1f2;color:#b91c1c;border:1px solid #fecdd3}
    .btn-danger:hover{background:#ffe4e6}
    .qualification-count{margin:10px 0 0;color:var(--muted);font-size:13px}
    @media(max-width:700px){
      .section-heading-row{flex-direction:column;align-items:stretch}
      .section-heading-row .btn{align-self:flex-start}
      .qualification-editor{padding:16px}
      .qualification-actions{justify-content:flex-start}
      .qualification-table-wrap{overflow-x:visible;border:0}
      .qualification-table,.qualification-table tbody,.qualification-table tr,.qualification-table td{display:block;width:100%;min-width:0}
      .qualification-table thead{display:none}
      .qualification-table tbody{display:grid;gap:12px}
      .qualification-table tr{border:1px solid var(--border);border-radius:9px;background:#fff;padding:12px}
      .qualification-table td{display:grid;grid-template-columns:120px minmax(0,1fr);gap:10px;padding:8px 4px;border:0}
      .qualification-table td::before{content:attr(data-label);font-weight:700;color:var(--text)}
      .qualification-table .empty-row td{display:block;text-align:center;padding:20px}
      .qualification-table .empty-row td::before{display:none}
    }


    /* Personal Statement */
    .statement-wrap{width:100%}
    .statement-textarea{
      width:100%;
      min-height:240px;
      resize:vertical;
      padding:14px 16px;
      border:1px solid #cbd5e1;
      border-radius:8px;
      background:#fff;
      color:var(--text);
      font:inherit;
      font-size:15px;
      line-height:1.65;
    }
    .statement-textarea:focus{outline:3px solid #bfdbfe;border-color:var(--primary)}
    .statement-meta{display:flex;justify-content:space-between;gap:16px;margin-top:8px;font-size:13px;color:var(--muted)}
    .statement-meta .invalid{color:#b91c1c;font-weight:700}
    @media(max-width:600px){
      .statement-textarea{min-height:220px}
      .statement-meta{flex-direction:column;gap:4px}
    }


    /* Learning Difficulty, Disability or Health Condition */
    .condition-grid{
      display:grid;
      grid-template-columns:repeat(2,minmax(0,1fr));
      gap:12px 24px;
      margin-top:18px;
    }
    .condition-option{
      display:flex;
      align-items:flex-start;
      gap:10px;
      min-height:42px;
      padding:10px 12px;
      border:1px solid var(--border);
      border-radius:8px;
      background:#fff;
      color:#475569;
      font-size:14px;
      line-height:1.45;
      cursor:pointer;
    }
    .condition-option input{
      width:18px;
      height:18px;
      margin:1px 0 0;
      flex:0 0 auto;
      accent-color:var(--primary);
    }
    .condition-option:has(input:checked){
      border-color:#93c5fd;
      background:var(--primary-light);
    }
    @media(max-width:600px){
      .condition-grid{grid-template-columns:1fr;gap:10px}
    }
    
    .bgError{
        color: #721c24; !important;
        background-color: #f8d7da !important;
        border: 1px solid #f5c6cb;
        position: relative;
        padding: .75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem;
        font-weight: bold !important;
    }

    .bgError ul li{
        font-weight: 100 !important;
    }

    .error{
        display: none !important;
    }

    .pad20{
        padding-top: 20px !important;
    }

    span {
        font-weight: 100 !important
    }
  </style>


    
<script>

    const toggle = (controlId, groupId) => {
        const control = document.getElementById(controlId), group = document.getElementById(groupId);
        if (!control || !group) return;
        const apply = () => { group.hidden = control.type === "checkbox" ? !control.checked : control.value !== "other"; };
        control.addEventListener("change", apply); apply();
    };


    document.addEventListener("DOMContentLoaded", function () {


        var requiredSpans = ["lblCriminalConvictionID"];
        requiredSpans.forEach(id => {
            const element = document.getElementById(id);

            if (element) {
                element.insertAdjacentHTML(
                    "beforeend",
                    ' <span style="color:red;">*</span>'
                );
            }
        });
    })

</script>


    <div class="step-content" id="step-content">
        <div>
            <asp:ValidationSummary ID="ValidationSummary1" runat="server" HeaderText="We found some errors in the information you provided. Please fix these errors:" CssClass="bgError" ForeColor="" />
        </div>
        <h1>Previous Convictions</h1>
        <p class="intro">Please answer the following question about any unspent criminal convictions, outstanding court proceedings or offender register status.</p>
        <section class="form-section">
            

            <div class="contact-grid">
            <div class="form-group full-width">
                <!--<label for="previous-convictions">
                Do you have any unspent criminal convictions, outstanding court proceedings, or are you on any offenders register?
                </label>-->
                
                <cc1:StudentEnrolmentField StudentEnrolmentFieldType="CriminalConvictionID" IsRequired="true" ID="CriminalConvictionID" LabelWidth="1000" runat="server"  CustomCaption="Do you have any unspent criminal convictions, outstanding court proceedings, or are you on any offenders register?"/>
            </div>
            </div>

            <div class="advice-box" style="margin-top:22px;">
            <strong>Important information:</strong>
            If you declare that you have a conviction, you will be contacted for further information.
            This information will help us assess any potential risks to yourself or others at college.
            The college has a duty of care to all of its staff and students to ensure that any risk to their safety is minimised.
            The college reserves the right not to enrol anyone who may pose a threat or danger to the safety of its staff and students.
            Having a criminal record will not necessarily prevent you from studying at the college.
            This is dependent on the nature of the course and the circumstances of the offence.
            If you do not disclose a conviction, this can result in disciplinary action or your enrolment being cancelled.
            </div>
        </section>
    </div>


<div class="card-footer">
    <cc1:CCCButton CssClass="btn btn-primary" ID="btnBack" runat="server" Text="← Back" LinkResource="checkout_aspx" />
    <cc1:CCCButton CssClass="btn btn-primary" ID="btnContinue" runat="server" Text="Next →" LinkResource="contactdetails_aspx" CausesValidation="True" /> <!---->
</div>

